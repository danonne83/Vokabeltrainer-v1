# VokabelTrainer Web-App

## Enthalten
- Responsive blau-weiße Web-App, für iPhone-Bildschirm optimiert
- Vokabeln manuell hinzufügen und löschen
- Foto aufnehmen/auswählen und Texterkennung (Tesseract.js, benötigt Internet)
- Erkannte Wortpaare prüfen und importieren
- Abfrage Englisch→Deutsch und Deutsch→Englisch
- Lernstatistik und CSV-Export
- Speicherung im Browser via localStorage
- PWA-Manifest und Service Worker

## Auf dem iPhone verwenden
Für „Zum Home-Bildschirm“ und Kamera/OCR zuverlässig nutzen, muss die App über eine HTTPS-Adresse bereitgestellt werden. Eine lokale HTML-Datei ist dafür nicht ausreichend.

Ein einfacher Weg:
1. ZIP entpacken.
2. Dateien `index.html`, `manifest.webmanifest` und `sw.js` auf einen HTTPS-Webhost hochladen (z. B. GitHub Pages).
3. Die HTTPS-Adresse in Safari auf dem iPhone XS öffnen.
4. Teilen → „Zum Home-Bildschirm“ → Hinzufügen.

OCR lädt Tesseract.js von einem CDN und benötigt beim ersten Start Internet. Die eigentliche Texterkennung läuft danach im Browser. Die App speichert Vokabeln lokal im Browser dieses Geräts, nicht automatisch in iCloud.
